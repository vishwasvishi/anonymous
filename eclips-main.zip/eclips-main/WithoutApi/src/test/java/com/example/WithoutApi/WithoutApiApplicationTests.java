package com.example.WithoutApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WithoutApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.mysqlpost2.Repository;

import org.springframework.data.repository.CrudRepository;

import com.example.mysqlpost2.Model.Student;

public interface Reppo extends CrudRepository<Student, Integer>{

}
